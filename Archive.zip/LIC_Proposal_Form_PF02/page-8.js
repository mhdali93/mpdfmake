const Page_8 = ({
  convertTextToRtl
}) => {
  return {
    layout : "customTableLayout",
    pageMargin : [0, 0, 0, 0],
    pageBreak : "after",
    fontSize : 9.5,
    table : {
      body : [
        [
          {
            border: [false, false, false, false],
            layout:{
              paddingBottom: (i, node) => 2,
              paddingTop: (i, node) => 2,
            },
            table: {
              widths: [
                10,280,240
              ],
              body: [
                [
                  {text:"34."},
                  {
                    stack:[
                      {
                        text:convertTextToRtl("يرجى توضيح بيانات البنوك التي تتعامل معها / أو التي لديك حساب فيها، يرجى توضيح "),
                        style: ["right", {fontSize: 9}, "arabic"]
                      },
                      {
                        text:convertTextToRtl("اسم البنك ونوع الحساب المصرفي )جاري / ادخار( )في حالة كان الحساب غير شخصي "),
                        style: ["right", {fontSize: 9}, "arabic"]
                      },
                      {
                        text:convertTextToRtl("وكانت جميع المعاملات البنكية تتم من حساب شركة، يجب توضيح بيانات حساب الشركة "),
                        style: ["right", {fontSize: 9}, "arabic"]
                      },
                      {
                        text:"Please provide details of banks you are dealing with/holding account with. Please provide bank name and type of account maintained (current/savings) (for UAE Customers) \nIn case no personal account is maintained and all transactions are being made from company account, details of company accounts should be provided."
                      }
                    ],
                    style:"justify"
                  },
                  {
                    stack:[
                      { text:"\n1. ___________________________________________" },
                      { text:"\n_____________________________________________" },
                      { text:"\n2. ___________________________________________" },
                      { text:"\n_____________________________________________" },
                    ],
                    style:{fontSize: 11},
                    border:[false, true, true, true],
                  }
                ],
              ],
            }
          }
        ],
        [
          {
            border: [false, false, false, false],
            layout:{
              paddingTop: (i, node) => 0
            },
            table: {
              widths: [550],
              body: [
                [
                  {
                    border: [false, false, false, false],
                    text:"Page 8",
                    style: ["center", {fontSize: 10}, "bold", "Times"]
                  }
                ]
              ],
            },
          }
        ],
      ]
    }
  }
}

module.exports = Page_8